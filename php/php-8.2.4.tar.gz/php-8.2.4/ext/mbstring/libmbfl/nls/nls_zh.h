#ifndef MBFL_NLS_ZH_H
#define MBFL_NLS_ZH_H

#include "mbfilter.h"

extern const mbfl_language mbfl_language_simplified_chinese;
extern const mbfl_language mbfl_language_traditional_chinese;

#endif /* MBFL_NLS_ZH_H */
